# Byron DB421E Doorbell

Raw DeBruijn (.sub) signal files for the Flipper Zero Sub-Ghz feature.

**Compatible with:**

- `Byron DB421E` - Receiver

<img src="receiver.jpg">
<img src="stock.jpg">
