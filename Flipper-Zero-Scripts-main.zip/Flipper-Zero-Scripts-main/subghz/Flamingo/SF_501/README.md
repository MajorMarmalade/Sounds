# Flamingo SF-501R / SF-501P

Raw DeBruijn (.sub) signal files for the Flipper Zero Sub-Ghz feature.

**Compatible with:**

- `Flamingo SF-501R` - Remote
- `Flamingo SF-501P` - Sockets

\* Might be compatible with more Flamingo Devices

<img src="remote.jpg">
<img src="socket.jpg">

**Pro Tip:** `You should add googly eyes to your remotes as well!`
