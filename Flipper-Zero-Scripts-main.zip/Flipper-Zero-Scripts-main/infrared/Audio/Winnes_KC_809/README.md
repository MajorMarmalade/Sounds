# Winnes KC-809 CD Player

Infra red signal files for the Flipper Zero.

**Compatible with:**

 - Winnes KC-809

<img src="player.jpg">
