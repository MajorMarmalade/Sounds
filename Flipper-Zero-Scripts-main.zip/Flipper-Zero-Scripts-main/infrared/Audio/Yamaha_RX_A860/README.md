# Yamaha RX-A860

Infra red signal files for the Flipper Zero.

**Compatible with:**

 - Yamaha RX-A860

<img src="front.jpg">
<img src="back.jpg">
