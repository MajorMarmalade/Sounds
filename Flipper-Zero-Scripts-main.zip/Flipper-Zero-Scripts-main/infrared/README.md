# IR Remotes

Collection of custom programmed remotes. Some remotes might not be completed and only contain my most used buttons.
