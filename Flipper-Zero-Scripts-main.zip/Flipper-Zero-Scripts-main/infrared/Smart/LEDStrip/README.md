# Generic Addressable RGB LED Strip Remote

Infra red signal files for the Flipper Zero.

Unbranded LED Strip remote with effects:

 - Flash
 - Jump
 - Meteor
 - Roll
 - Auto

<img src="remote.jpg">
