# Sony KDL-55HX850

Infra red signal files for the Flipper Zero.

**Compatible with:**

 - Sony KDL-55HX850

<img src="remote.jpg">
